// Problem 1

var num1 = 529;
var num2 = 432;

var string1 = "This is the first part of the string.";
var string2 = " This is the second part of the string.";

console.log(num1 + num2);
console.log(string1 + string2);

// Problem 2

var rapperArray = [
    ['Little Uzi','Travis Scott'],
    ['Kanye','Drake'],
    ['Chance the Rapper', 'Childish Gambino'],
    ['Migos', 'Big Sean']
  ];

console.log(rapperArray[0][1]);
console.log(rapperArray[1][1]);
